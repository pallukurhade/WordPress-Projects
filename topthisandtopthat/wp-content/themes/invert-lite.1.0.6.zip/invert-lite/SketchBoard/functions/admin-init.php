<?php
/********************************************
 THEME VARIABLES & INCLUDE ALL REQUIRED FILES
*********************************************/
global $invert_themename;
global $invert_shortname;
require_once('sketch-functions.php'); // pagination, excerpt control etc..
require_once('sketch-enqueue.php');   // Enqueue Css Scripts
require_once('sketch-breadcrumb.php');// custom post types includes
require_once('skt-frontpage-sections-metabox.php');// Home Page Meta Box
