<h2><?php _e('WP All Import Support', 'pmxi_plugin') ?></h2>

<table class="layout">
	<tr>
		<td class="left">
			<p style='font-size: 1.3em;'>
				<b>E-mail</b> - <a href='mailto:support@wpallimport.com'>support@wpallimport.com</a><br />
				<b>Support page</b> - <a href='http://www.wpallimport.com/support?utm_source=wordpress.org&utm_medium=support&utm_campaign=free+plugin' target='_blank'>http://www.wpallimport.com/support</a>
			</p>

			<p style='font-size: 1.3em;'>Thanks for installing the free version of WP All Import.</p>

			<p style='font-size: 1.3em;'>We are able to provide limited technical support to free version users. Support is not guaranteed, and is based on availability</p>

			<p style='font-size: 1.3em;'><b>Please note we generally do not provide technical support via the WordPress.org community forums.</b></p>

			<p style='font-size: 1.3em;'><a href='http://www.wpallimport.com/upgrade-to-pro?utm_source=wordpress.org&utm_medium=support&utm_campaign=free+plugin' target='_blank'>For premium support, please upgrade to the professional edition of WP All Import.</a></p>


		</td>
		<td class="right">&nbsp;</td>
	</tr>
</table>